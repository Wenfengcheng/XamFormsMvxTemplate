﻿using MvvmCross.Forms.Core;

namespace $safeprojectname$.Pages
{
    public partial class SecondPage : MvxContentPage
    {
        public SecondPage()
        {
            InitializeComponent();
        }
    }
}
