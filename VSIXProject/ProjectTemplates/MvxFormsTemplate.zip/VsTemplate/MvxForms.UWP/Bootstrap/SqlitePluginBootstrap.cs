using MvvmCross.Platform.Plugins;

namespace $safeprojectname$.Bootstrap
{
    /*public class SqlitePluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.Sqlite.PluginLoader>
		{}*/
}
