﻿using MvvmCross.Forms.Core;

namespace $safeprojectname$.Pages
{
    public partial class MainPage : MvxContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
