﻿// ---------------------------------------------------------------
// <author>Paul Datsyuk</author>
// <url>https://www.linkedin.com/in/pauldatsyuk/</url>
// ---------------------------------------------------------------

using MvvmCross.Forms.Views;

namespace $safeprojectname$.Pages
{
    public partial class SecondPage : MvxContentPage
    {
        public SecondPage()
        {
            InitializeComponent();
        }
    }
}
