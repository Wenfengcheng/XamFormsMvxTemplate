﻿// ---------------------------------------------------------------
// <author>Paul Datsyuk</author>
// <url>https://www.linkedin.com/in/pauldatsyuk/</url>
// ---------------------------------------------------------------

namespace $safeprojectname$.Services
{
    public interface IAppSettings
    {
        int SuperNumber { get; set; }
    }
}