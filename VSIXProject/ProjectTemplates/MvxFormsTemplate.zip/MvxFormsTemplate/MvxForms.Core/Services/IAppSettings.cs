﻿namespace $safeprojectname$.Services
{
    public interface IAppSettings
    {
        int SuperNumber { get; set; }
    }
}