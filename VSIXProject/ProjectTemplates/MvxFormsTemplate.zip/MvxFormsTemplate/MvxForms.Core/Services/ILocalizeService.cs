﻿using System.Globalization;

namespace $safeprojectname$.Services
{
    public interface ILocalizeService
    {
        CultureInfo GetCurrentCultureInfo();
    }
}
