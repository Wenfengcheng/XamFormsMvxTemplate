﻿// ---------------------------------------------------------------
// <author>Paul Datsyuk</author>
// <url>https://www.linkedin.com/in/pauldatsyuk/</url>
// ---------------------------------------------------------------

using Xunit;

namespace $safeprojectname$
{
    public class Tests
    {
        [Fact]
        public void PassingTest()
        {
            Assert.Equal(4, 4);
        }
    }
}
