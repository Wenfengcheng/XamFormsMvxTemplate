﻿using Xamarin.Forms;

namespace $safeprojectname$.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
